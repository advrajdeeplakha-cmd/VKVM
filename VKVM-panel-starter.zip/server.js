const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/login", (req, res) => {
  const { username, password } = req.body || {};
  if (username === "admin" && password === "admin") {
    return res.json({ ok: true, message: "Login successful" });
  }
  res.status(401).json({ ok: false, message: "Invalid username or password" });
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, panel: "VKVM", port: PORT });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`VKVM running on http://127.0.0.1:${PORT}`);
});