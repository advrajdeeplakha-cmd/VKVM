#!/usr/bin/env bash
set -e
echo "=== VKVM Panel Installer ==="

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is required."
  echo "Ubuntu/Debian: sudo apt update && sudo apt install -y nodejs npm"
  exit 1
fi

mkdir -p /opt/vkvm
cp -r . /opt/vkvm
cd /opt/vkvm
npm install --omit=dev

cat >/etc/systemd/system/vkvm.service <<'EOF'
[Unit]
Description=VKVM Panel
After=network.target

[Service]
WorkingDirectory=/opt/vkvm
ExecStart=/usr/bin/node /opt/vkvm/server.js
Restart=always
Environment=PORT=5000

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now vkvm
echo
echo "VKVM is running on http://SERVER-IP:5000"
echo "Development login: admin / admin"
