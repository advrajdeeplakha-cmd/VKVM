# VKVM Panel

Starter self-hosted VPS control panel.

## Termux/local test

```bash
pkg update -y
pkg install -y nodejs
cd VKVM
npm install
npm start
```

Open:

http://127.0.0.1:5000

Login:

- Username: `admin`
- Password: `admin`

## Current status

This starter includes the UI, login and health API. Proxmox API/LXC provisioning is intentionally not wired yet. The next build should add secure Proxmox API tokens, LXC creation, start/stop/restart, console, reinstall, resources and node management.

Do not expose the development `admin/admin` credentials publicly.
